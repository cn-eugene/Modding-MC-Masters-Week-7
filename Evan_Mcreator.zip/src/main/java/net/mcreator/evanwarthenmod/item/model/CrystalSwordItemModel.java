package net.mcreator.evanwarthenmod.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.evanwarthenmod.item.CrystalSwordItem;

public class CrystalSwordItemModel extends GeoModel<CrystalSwordItem> {
	@Override
	public ResourceLocation getAnimationResource(CrystalSwordItem animatable) {
		return new ResourceLocation("evan_warthen_mod", "animations/crystal_sword.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(CrystalSwordItem animatable) {
		return new ResourceLocation("evan_warthen_mod", "geo/crystal_sword.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(CrystalSwordItem animatable) {
		return new ResourceLocation("evan_warthen_mod", "textures/item/ereteryuru.png");
	}
}
