
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class EvanWarthenModModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.PUMPKIN_PIE), new ItemStack(EvanWarthenModModBlocks.BLUE.get()), new ItemStack(Items.DIAMOND_SWORD), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.ENCHANTING_TABLE),

					new ItemStack(EvanWarthenModModBlocks.BLUE.get()), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.MUSIC_DISC_MELLOHI),

					new ItemStack(Items.PUMPKIN_PIE), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.DRAGON_HEAD),

					new ItemStack(EvanWarthenModModBlocks.BLUE.get(), 64), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(EvanWarthenModModBlocks.BLUE.get(), 64),

					new ItemStack(Items.ENDER_DRAGON_SPAWN_EGG), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE),

					new ItemStack(EvanWarthenModModItems.BOXLAND.get(), 64), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(EvanWarthenModModItems.MAIR_INGOT.get(), 64),

					new ItemStack(Items.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE), 10, 5, 0.05f));
		}
		if (event.getType() == EvanWarthenModModVillagerProfessions.HOOMER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.DIAMOND_SWORD),

					new ItemStack(Items.ENDER_EYE, 12), 10, 5, 0.05f));
		}
	}
}
