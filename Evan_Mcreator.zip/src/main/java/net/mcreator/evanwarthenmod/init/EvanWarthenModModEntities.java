
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.evanwarthenmod.entity.RobotblueEntity;
import net.mcreator.evanwarthenmod.entity.JungleslimeEntity;
import net.mcreator.evanwarthenmod.entity.BombEntity;
import net.mcreator.evanwarthenmod.entity.AliencreeperEntity;
import net.mcreator.evanwarthenmod.entity.Aliencreeper2EntityProjectile;
import net.mcreator.evanwarthenmod.entity.Aliencreeper2Entity;
import net.mcreator.evanwarthenmod.EvanWarthenModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EvanWarthenModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EvanWarthenModMod.MODID);
	public static final RegistryObject<EntityType<AliencreeperEntity>> ALIENCREEPER = register("aliencreeper",
			EntityType.Builder.<AliencreeperEntity>of(AliencreeperEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AliencreeperEntity::new)

					.sized(0.6f, 1.7f));
	public static final RegistryObject<EntityType<BombEntity>> BOMB = register("bomb",
			EntityType.Builder.<BombEntity>of(BombEntity::new, MobCategory.MISC).setCustomClientFactory(BombEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Aliencreeper2Entity>> ALIENCREEPER_2 = register("aliencreeper_2",
			EntityType.Builder.<Aliencreeper2Entity>of(Aliencreeper2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Aliencreeper2Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<Aliencreeper2EntityProjectile>> ALIENCREEPER_2_PROJECTILE = register("projectile_aliencreeper_2",
			EntityType.Builder.<Aliencreeper2EntityProjectile>of(Aliencreeper2EntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1)
					.setCustomClientFactory(Aliencreeper2EntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<JungleslimeEntity>> JUNGLESLIME = register("jungleslime",
			EntityType.Builder.<JungleslimeEntity>of(JungleslimeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(JungleslimeEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<RobotblueEntity>> ROBOTBLUE = register("robotblue",
			EntityType.Builder.<RobotblueEntity>of(RobotblueEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(RobotblueEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			AliencreeperEntity.init();
			Aliencreeper2Entity.init();
			JungleslimeEntity.init();
			RobotblueEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ALIENCREEPER.get(), AliencreeperEntity.createAttributes().build());
		event.put(ALIENCREEPER_2.get(), Aliencreeper2Entity.createAttributes().build());
		event.put(JUNGLESLIME.get(), JungleslimeEntity.createAttributes().build());
		event.put(ROBOTBLUE.get(), RobotblueEntity.createAttributes().build());
	}
}
