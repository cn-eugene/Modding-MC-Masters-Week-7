
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.evanwarthenmod.client.renderer.RobotblueRenderer;
import net.mcreator.evanwarthenmod.client.renderer.JungleslimeRenderer;
import net.mcreator.evanwarthenmod.client.renderer.AliencreeperRenderer;
import net.mcreator.evanwarthenmod.client.renderer.Aliencreeper2Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EvanWarthenModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EvanWarthenModModEntities.ALIENCREEPER.get(), AliencreeperRenderer::new);
		event.registerEntityRenderer(EvanWarthenModModEntities.BOMB.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EvanWarthenModModEntities.ALIENCREEPER_2.get(), Aliencreeper2Renderer::new);
		event.registerEntityRenderer(EvanWarthenModModEntities.ALIENCREEPER_2_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EvanWarthenModModEntities.JUNGLESLIME.get(), JungleslimeRenderer::new);
		event.registerEntityRenderer(EvanWarthenModModEntities.ROBOTBLUE.get(), RobotblueRenderer::new);
	}
}
