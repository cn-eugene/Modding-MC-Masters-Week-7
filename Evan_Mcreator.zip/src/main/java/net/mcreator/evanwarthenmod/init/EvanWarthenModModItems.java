
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.evanwarthenmod.item.MairorearmorItem;
import net.mcreator.evanwarthenmod.item.MairItem;
import net.mcreator.evanwarthenmod.item.MairIngotItem;
import net.mcreator.evanwarthenmod.item.EvanItem;
import net.mcreator.evanwarthenmod.item.CrystalSwordItem;
import net.mcreator.evanwarthenmod.item.BoxlandItem;
import net.mcreator.evanwarthenmod.item.BoomboomItem;
import net.mcreator.evanwarthenmod.EvanWarthenModMod;

public class EvanWarthenModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EvanWarthenModMod.MODID);
	public static final RegistryObject<Item> MAIR_INGOT = REGISTRY.register("mair_ingot", () -> new MairIngotItem());
	public static final RegistryObject<Item> MAIR_ORE = block(EvanWarthenModModBlocks.MAIR_ORE);
	public static final RegistryObject<Item> MAIR_BLOCK = block(EvanWarthenModModBlocks.MAIR_BLOCK);
	public static final RegistryObject<Item> MAIR = REGISTRY.register("mair", () -> new MairItem());
	public static final RegistryObject<Item> EVAN = REGISTRY.register("evan", () -> new EvanItem());
	public static final RegistryObject<Item> BOX = block(EvanWarthenModModBlocks.BOX);
	public static final RegistryObject<Item> BOXLAND = REGISTRY.register("boxland", () -> new BoxlandItem());
	public static final RegistryObject<Item> BLUE = block(EvanWarthenModModBlocks.BLUE);
	public static final RegistryObject<Item> MOBEXP = block(EvanWarthenModModBlocks.MOBEXP);
	public static final RegistryObject<Item> ALIENCREEPER_SPAWN_EGG = REGISTRY.register("aliencreeper_spawn_egg", () -> new ForgeSpawnEggItem(EvanWarthenModModEntities.ALIENCREEPER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> MAIROREARMOR_HELMET = REGISTRY.register("mairorearmor_helmet", () -> new MairorearmorItem.Helmet());
	public static final RegistryObject<Item> MAIROREARMOR_CHESTPLATE = REGISTRY.register("mairorearmor_chestplate", () -> new MairorearmorItem.Chestplate());
	public static final RegistryObject<Item> MAIROREARMOR_LEGGINGS = REGISTRY.register("mairorearmor_leggings", () -> new MairorearmorItem.Leggings());
	public static final RegistryObject<Item> MAIROREARMOR_BOOTS = REGISTRY.register("mairorearmor_boots", () -> new MairorearmorItem.Boots());
	public static final RegistryObject<Item> BOOMBOOM = REGISTRY.register("boomboom", () -> new BoomboomItem());
	public static final RegistryObject<Item> ALIENCREEPER_2_SPAWN_EGG = REGISTRY.register("aliencreeper_2_spawn_egg", () -> new ForgeSpawnEggItem(EvanWarthenModModEntities.ALIENCREEPER_2, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> JUNGLESLIME_SPAWN_EGG = REGISTRY.register("jungleslime_spawn_egg", () -> new ForgeSpawnEggItem(EvanWarthenModModEntities.JUNGLESLIME, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> SEETHROOWOOD = block(EvanWarthenModModBlocks.SEETHROOWOOD);
	public static final RegistryObject<Item> SEETHROOGRASS = block(EvanWarthenModModBlocks.SEETHROOGRASS);
	public static final RegistryObject<Item> SEETHROODIRT = block(EvanWarthenModModBlocks.SEETHROODIRT);
	public static final RegistryObject<Item> SEE_THROOLEAVES = block(EvanWarthenModModBlocks.SEE_THROOLEAVES);
	public static final RegistryObject<Item> SEETHROOCLAY = block(EvanWarthenModModBlocks.SEETHROOCLAY);
	public static final RegistryObject<Item> SEETHROOFLOWER = block(EvanWarthenModModBlocks.SEETHROOFLOWER);
	public static final RegistryObject<Item> ROBOTBLUE_SPAWN_EGG = REGISTRY.register("robotblue_spawn_egg", () -> new ForgeSpawnEggItem(EvanWarthenModModEntities.ROBOTBLUE, -13421569, -13369345, new Item.Properties()));
	public static final RegistryObject<Item> CRYSTAL_SWORD = REGISTRY.register("crystal_sword", () -> new CrystalSwordItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
