
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.evanwarthenmod.enchantment.LightningEnchantment;
import net.mcreator.evanwarthenmod.EvanWarthenModMod;

public class EvanWarthenModModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, EvanWarthenModMod.MODID);
	public static final RegistryObject<Enchantment> LIGHTNING = REGISTRY.register("lightning", () -> new LightningEnchantment());
}
