
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.evanwarthenmod.EvanWarthenModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EvanWarthenModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EvanWarthenModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(EvanWarthenModModBlocks.MAIR_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(EvanWarthenModModBlocks.MOBEXP.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EvanWarthenModModItems.MAIR.get());
			tabData.accept(EvanWarthenModModItems.MAIROREARMOR_HELMET.get());
			tabData.accept(EvanWarthenModModItems.MAIROREARMOR_CHESTPLATE.get());
			tabData.accept(EvanWarthenModModItems.MAIROREARMOR_LEGGINGS.get());
			tabData.accept(EvanWarthenModModItems.MAIROREARMOR_BOOTS.get());
			tabData.accept(EvanWarthenModModItems.CRYSTAL_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EvanWarthenModModItems.ALIENCREEPER_SPAWN_EGG.get());
			tabData.accept(EvanWarthenModModItems.ALIENCREEPER_2_SPAWN_EGG.get());
			tabData.accept(EvanWarthenModModItems.JUNGLESLIME_SPAWN_EGG.get());
			tabData.accept(EvanWarthenModModItems.ROBOTBLUE_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EvanWarthenModModItems.MAIR_INGOT.get());
			tabData.accept(EvanWarthenModModItems.EVAN.get());
			tabData.accept(EvanWarthenModModItems.BOXLAND.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EvanWarthenModModBlocks.MAIR_ORE.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.BLUE.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.SEETHROOWOOD.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.SEETHROOGRASS.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.SEETHROODIRT.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.SEE_THROOLEAVES.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.SEETHROOCLAY.get().asItem());
			tabData.accept(EvanWarthenModModBlocks.SEETHROOFLOWER.get().asItem());
		}
	}
}
