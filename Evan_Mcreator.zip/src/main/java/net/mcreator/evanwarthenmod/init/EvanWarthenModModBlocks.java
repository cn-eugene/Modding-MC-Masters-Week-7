
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.evanwarthenmod.block.SeethroowoodBlock;
import net.mcreator.evanwarthenmod.block.SeethroograssBlock;
import net.mcreator.evanwarthenmod.block.SeethrooflowerBlock;
import net.mcreator.evanwarthenmod.block.SeethroodirtBlock;
import net.mcreator.evanwarthenmod.block.SeethrooclayBlock;
import net.mcreator.evanwarthenmod.block.SeeThrooleavesBlock;
import net.mcreator.evanwarthenmod.block.MobexpBlock;
import net.mcreator.evanwarthenmod.block.MairOreBlock;
import net.mcreator.evanwarthenmod.block.MairBlockBlock;
import net.mcreator.evanwarthenmod.block.BoxlandPortalBlock;
import net.mcreator.evanwarthenmod.block.BoxBlock;
import net.mcreator.evanwarthenmod.block.BlueBlock;
import net.mcreator.evanwarthenmod.EvanWarthenModMod;

public class EvanWarthenModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EvanWarthenModMod.MODID);
	public static final RegistryObject<Block> MAIR_ORE = REGISTRY.register("mair_ore", () -> new MairOreBlock());
	public static final RegistryObject<Block> MAIR_BLOCK = REGISTRY.register("mair_block", () -> new MairBlockBlock());
	public static final RegistryObject<Block> BOX = REGISTRY.register("box", () -> new BoxBlock());
	public static final RegistryObject<Block> BOXLAND_PORTAL = REGISTRY.register("boxland_portal", () -> new BoxlandPortalBlock());
	public static final RegistryObject<Block> BLUE = REGISTRY.register("blue", () -> new BlueBlock());
	public static final RegistryObject<Block> MOBEXP = REGISTRY.register("mobexp", () -> new MobexpBlock());
	public static final RegistryObject<Block> SEETHROOWOOD = REGISTRY.register("seethroowood", () -> new SeethroowoodBlock());
	public static final RegistryObject<Block> SEETHROOGRASS = REGISTRY.register("seethroograss", () -> new SeethroograssBlock());
	public static final RegistryObject<Block> SEETHROODIRT = REGISTRY.register("seethroodirt", () -> new SeethroodirtBlock());
	public static final RegistryObject<Block> SEE_THROOLEAVES = REGISTRY.register("see_throoleaves", () -> new SeeThrooleavesBlock());
	public static final RegistryObject<Block> SEETHROOCLAY = REGISTRY.register("seethrooclay", () -> new SeethrooclayBlock());
	public static final RegistryObject<Block> SEETHROOFLOWER = REGISTRY.register("seethrooflower", () -> new SeethrooflowerBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
