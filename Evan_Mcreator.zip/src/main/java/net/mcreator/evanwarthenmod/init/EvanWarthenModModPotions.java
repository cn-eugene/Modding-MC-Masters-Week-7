
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthenmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.evanwarthenmod.EvanWarthenModMod;

public class EvanWarthenModModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, EvanWarthenModMod.MODID);
	public static final RegistryObject<Potion> POISINAPOSHIN = REGISTRY.register("poisinaposhin", () -> new Potion(new MobEffectInstance(EvanWarthenModModMobEffects.POISINA.get(), 3600, 0, false, true),
			new MobEffectInstance(MobEffects.BLINDNESS, 3600, 0, false, true), new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3600, 0, false, true)));
}
