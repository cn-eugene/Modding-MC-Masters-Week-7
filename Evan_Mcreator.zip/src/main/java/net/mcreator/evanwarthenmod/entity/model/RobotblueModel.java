package net.mcreator.evanwarthenmod.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.evanwarthenmod.entity.RobotblueEntity;

public class RobotblueModel extends GeoModel<RobotblueEntity> {
	@Override
	public ResourceLocation getAnimationResource(RobotblueEntity entity) {
		return new ResourceLocation("evan_warthen_mod", "animations/robot_blue.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(RobotblueEntity entity) {
		return new ResourceLocation("evan_warthen_mod", "geo/robot_blue.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(RobotblueEntity entity) {
		return new ResourceLocation("evan_warthen_mod", "textures/entities/" + entity.getTexture() + ".png");
	}

}
