package net.mcreator.evanwarthenmod.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.evanwarthenmod.entity.JungleslimeEntity;

public class JungleslimeModel extends GeoModel<JungleslimeEntity> {
	@Override
	public ResourceLocation getAnimationResource(JungleslimeEntity entity) {
		return new ResourceLocation("evan_warthen_mod", "animations/jungle_slime.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(JungleslimeEntity entity) {
		return new ResourceLocation("evan_warthen_mod", "geo/jungle_slime.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(JungleslimeEntity entity) {
		return new ResourceLocation("evan_warthen_mod", "textures/entities/" + entity.getTexture() + ".png");
	}

}
