package net.mcreator.evanwarthenmod.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.evanwarthenmod.entity.Aliencreeper2Entity;

public class Aliencreeper2Model extends GeoModel<Aliencreeper2Entity> {
	@Override
	public ResourceLocation getAnimationResource(Aliencreeper2Entity entity) {
		return new ResourceLocation("evan_warthen_mod", "animations/alien_creeper_-_converted.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(Aliencreeper2Entity entity) {
		return new ResourceLocation("evan_warthen_mod", "geo/alien_creeper_-_converted.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(Aliencreeper2Entity entity) {
		return new ResourceLocation("evan_warthen_mod", "textures/entities/" + entity.getTexture() + ".png");
	}

}
