
package net.mcreator.micahjacobsonmod.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.util.ForgeSoundType;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class RainboworeBlock extends FallingBlock {
	public RainboworeBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
				.sound(new ForgeSoundType(1.0f, 1.0f, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.nether_gold_ore.break")), () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.nether_gold_ore.step")),
						() -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.nether_gold_ore.place")), () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.nether_gold_ore.hit")),
						() -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.nether_gold_ore.fall"))))
				.strength(1000f).lightLevel(s -> 15).requiresCorrectToolForDrops().friction(5f).speedFactor(10f).jumpFactor(10f));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
