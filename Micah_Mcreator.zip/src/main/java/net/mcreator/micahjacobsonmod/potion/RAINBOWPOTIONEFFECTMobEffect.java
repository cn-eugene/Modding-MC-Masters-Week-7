
package net.mcreator.micahjacobsonmod.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.micahjacobsonmod.procedures.RAINBOWPOTIONEFFECTOnEffectActiveTickProcedure;

public class RAINBOWPOTIONEFFECTMobEffect extends MobEffect {
	public RAINBOWPOTIONEFFECTMobEffect() {
		super(MobEffectCategory.HARMFUL, -10092442);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		RAINBOWPOTIONEFFECTOnEffectActiveTickProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
