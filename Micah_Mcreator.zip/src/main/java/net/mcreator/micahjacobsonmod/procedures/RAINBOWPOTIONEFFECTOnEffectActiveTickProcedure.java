package net.mcreator.micahjacobsonmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.SpectralArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

public class RAINBOWPOTIONEFFECTOnEffectActiveTickProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel projectileLevel) {
			Projectile _entityToSpawn = new Object() {
				public Projectile getArrow(Level level, float damage, int knockback, byte piercing) {
					AbstractArrow entityToSpawn = new SpectralArrow(EntityType.SPECTRAL_ARROW, level);
					entityToSpawn.setBaseDamage(damage);
					entityToSpawn.setKnockback(knockback);
					entityToSpawn.setPierceLevel(piercing);
					entityToSpawn.setSecondsOnFire(100);
					entityToSpawn.setCritArrow(true);
					entityToSpawn.pickup = AbstractArrow.Pickup.ALLOWED;
					return entityToSpawn;
				}
			}.getArrow(projectileLevel, 1, 100, (byte) 10);
			_entityToSpawn.setPos((entity.getX()), (5 + entity.getY()), (entity.getZ()));
			_entityToSpawn.shoot(0, ((entity.getDirection()).getStepY()), 0, 1, 0);
			projectileLevel.addFreshEntity(_entityToSpawn);
		}
	}
}
