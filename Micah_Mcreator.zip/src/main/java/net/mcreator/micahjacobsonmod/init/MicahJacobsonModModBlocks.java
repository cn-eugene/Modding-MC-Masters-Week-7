
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.micahjacobsonmod.block.YellowstreetblockBlock;
import net.mcreator.micahjacobsonmod.block.WhitestreetblockBlock;
import net.mcreator.micahjacobsonmod.block.SkyscraperblockBlock;
import net.mcreator.micahjacobsonmod.block.RainbowwoodBlock;
import net.mcreator.micahjacobsonmod.block.RainbowtntBlock;
import net.mcreator.micahjacobsonmod.block.RainboworeBlock;
import net.mcreator.micahjacobsonmod.block.RainbowblockBlock;
import net.mcreator.micahjacobsonmod.block.BlackStreetblockBlock;
import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<Block> RAINBOWORE = REGISTRY.register("rainbowore", () -> new RainboworeBlock());
	public static final RegistryObject<Block> RAINBOWBLOCK = REGISTRY.register("rainbowblock", () -> new RainbowblockBlock());
	public static final RegistryObject<Block> RAINBOWTNT = REGISTRY.register("rainbowtnt", () -> new RainbowtntBlock());
	public static final RegistryObject<Block> BLACK_STREETBLOCK = REGISTRY.register("black_streetblock", () -> new BlackStreetblockBlock());
	public static final RegistryObject<Block> YELLOWSTREETBLOCK = REGISTRY.register("yellowstreetblock", () -> new YellowstreetblockBlock());
	public static final RegistryObject<Block> WHITESTREETBLOCK = REGISTRY.register("whitestreetblock", () -> new WhitestreetblockBlock());
	public static final RegistryObject<Block> RAINBOWWOOD = REGISTRY.register("rainbowwood", () -> new RainbowwoodBlock());
	public static final RegistryObject<Block> SKYSCRAPERBLOCK = REGISTRY.register("skyscraperblock", () -> new SkyscraperblockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
