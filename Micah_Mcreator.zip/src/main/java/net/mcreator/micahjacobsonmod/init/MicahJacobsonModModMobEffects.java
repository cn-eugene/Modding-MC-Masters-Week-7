
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.micahjacobsonmod.potion.RAINBOWPOTIONEFFECTMobEffect;
import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<MobEffect> RAINBOWPOTIONEFFECT = REGISTRY.register("rainbowpotioneffect", () -> new RAINBOWPOTIONEFFECTMobEffect());
}
