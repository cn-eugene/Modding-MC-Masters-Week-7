
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.micahjacobsonmod.enchantment.RainbowluckEnchantment;
import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<Enchantment> RAINBOWLUCK = REGISTRY.register("rainbowluck", () -> new RainbowluckEnchantment());
}
