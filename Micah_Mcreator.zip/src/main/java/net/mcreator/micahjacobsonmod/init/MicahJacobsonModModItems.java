
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.micahjacobsonmod.item.TotemofsusItem;
import net.mcreator.micahjacobsonmod.item.RainbowswordItem;
import net.mcreator.micahjacobsonmod.item.RainbowshieldItem;
import net.mcreator.micahjacobsonmod.item.RainbowpickaxeItem;
import net.mcreator.micahjacobsonmod.item.RainbowingotItem;
import net.mcreator.micahjacobsonmod.item.RainbowarmorItem;
import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MicahJacobsonModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<Item> RAINBOWINGOT = REGISTRY.register("rainbowingot", () -> new RainbowingotItem());
	public static final RegistryObject<Item> RAINBOWORE = block(MicahJacobsonModModBlocks.RAINBOWORE);
	public static final RegistryObject<Item> RAINBOWSWORD = REGISTRY.register("rainbowsword", () -> new RainbowswordItem());
	public static final RegistryObject<Item> RAINBOWPICKAXE = REGISTRY.register("rainbowpickaxe", () -> new RainbowpickaxeItem());
	public static final RegistryObject<Item> RAINBOWBLOCK = block(MicahJacobsonModModBlocks.RAINBOWBLOCK);
	public static final RegistryObject<Item> RAINBOWTNT = block(MicahJacobsonModModBlocks.RAINBOWTNT);
	public static final RegistryObject<Item> RAINBOWARMOR_HELMET = REGISTRY.register("rainbowarmor_helmet", () -> new RainbowarmorItem.Helmet());
	public static final RegistryObject<Item> RAINBOWARMOR_CHESTPLATE = REGISTRY.register("rainbowarmor_chestplate", () -> new RainbowarmorItem.Chestplate());
	public static final RegistryObject<Item> RAINBOWARMOR_LEGGINGS = REGISTRY.register("rainbowarmor_leggings", () -> new RainbowarmorItem.Leggings());
	public static final RegistryObject<Item> RAINBOWARMOR_BOOTS = REGISTRY.register("rainbowarmor_boots", () -> new RainbowarmorItem.Boots());
	public static final RegistryObject<Item> DHARMANNNOOB_SPAWN_EGG = REGISTRY.register("dharmannnoob_spawn_egg", () -> new ForgeSpawnEggItem(MicahJacobsonModModEntities.DHARMANNNOOB, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> RAINBOWSHIELD = REGISTRY.register("rainbowshield", () -> new RainbowshieldItem());
	public static final RegistryObject<Item> TOTEMOFSUS = REGISTRY.register("totemofsus", () -> new TotemofsusItem());
	public static final RegistryObject<Item> BLACK_STREETBLOCK = block(MicahJacobsonModModBlocks.BLACK_STREETBLOCK);
	public static final RegistryObject<Item> YELLOWSTREETBLOCK = block(MicahJacobsonModModBlocks.YELLOWSTREETBLOCK);
	public static final RegistryObject<Item> WHITESTREETBLOCK = block(MicahJacobsonModModBlocks.WHITESTREETBLOCK);
	public static final RegistryObject<Item> RAINBOWWOOD = block(MicahJacobsonModModBlocks.RAINBOWWOOD);
	public static final RegistryObject<Item> SKYSCRAPERBLOCK = block(MicahJacobsonModModBlocks.SKYSCRAPERBLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(RAINBOWSHIELD.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
		});
	}
}
