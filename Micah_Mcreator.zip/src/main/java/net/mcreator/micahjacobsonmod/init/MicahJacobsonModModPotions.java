
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<Potion> RAINBOWPOTION = REGISTRY.register("rainbowpotion", () -> new Potion(new MobEffectInstance(MicahJacobsonModModMobEffects.RAINBOWPOTIONEFFECT.get(), 3600, 0, false, true)));
}
